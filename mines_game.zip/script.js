
let grid = document.getElementById("grid");
let mineCountInput = document.getElementById("mineCount");
let mines = [];

function startGame() {
    grid.innerHTML = "";
    mines = [];

    let mineCount = parseInt(mineCountInput.value);
    let totalCells = 25;
    let mineIndices = new Set();

    while (mineIndices.size < mineCount) {
        mineIndices.add(Math.floor(Math.random() * totalCells));
    }

    for (let i = 0; i < totalCells; i++) {
        let cell = document.createElement("div");
        cell.classList.add("cell");

        if (mineIndices.has(i)) {
            mines.push(true);
        } else {
            mines.push(false);
        }

        cell.addEventListener("click", () => revealCell(i, cell));
        grid.appendChild(cell);
    }
}

function revealCell(index, cell) {
    if (mines[index]) {
        cell.style.backgroundColor = "red";
        alert("💣 Boom! You hit a mine.");
    } else {
        cell.classList.add("revealed");
        cell.innerHTML = "⭐";
    }
}

function getSignal() {
    alert("Сигнал временно недоступен...");
}
